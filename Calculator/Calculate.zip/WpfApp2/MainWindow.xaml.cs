﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            hesab.Content = "0";
        }

       

        private void _9_Click(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {
                hesab.Content = _9.Content;
            }
            else
            {
                hesab.Content += _9.Content.ToString();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {
               
            }
            else
            {
                for (int i = 0; i < s.Length; i++)
                {
                    if(s[i]=='+' || s[i] == '-' || s[i] == '*' || s[i] == '/' )
                    {
                        equals_Click(sender, e);
                        
                    }
                }
                hesab.Content +=plus.Content.ToString();
            }
        }

        private void Equals_Click(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void _8_Click(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {
                hesab.Content = _8.Content;
            }
            else
            {
                hesab.Content += _8.Content.ToString();
            }
        }

        private void _7_Click(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {
                hesab.Content = _7.Content;
            }
            else
            {
                hesab.Content += _7.Content.ToString();
            }
        }

        private void _6_Click(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {
                hesab.Content = _6.Content;
            }
            else
            {
                hesab.Content += _6.Content.ToString();
            }
        }

        private void _5_Click(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {
                hesab.Content = _5.Content;
            }
            else
            {
                hesab.Content += _5.Content.ToString();
            }
        }

        private void _4_Click(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {
                hesab.Content = _4.Content;
            }
            else
            {
                hesab.Content += _4.Content.ToString();
            }
        }

        private void _3_Click(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {
                hesab.Content = _3.Content;
            }
            else
            {
                hesab.Content += _3.Content.ToString();
            }
        }

        private void _2_Click(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {
                hesab.Content = _2.Content;
            }
            else
            {
                hesab.Content += _2.Content.ToString();
            }
        }

        private void _1_Click(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {
                hesab.Content = _1.Content;
            }
            else
            {
                hesab.Content += _1.Content.ToString();
            }
        }

        private void _0_Click(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {
                hesab.Content = _0.Content;
            }
            else
            {
                hesab.Content += _0.Content.ToString();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            hesab.Content = "0";
        }

        private void equals_Click(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            string s1="";
            string s2="";
            char c = '+';
            bool test = false;
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/')
               {
                c = s[i];
                test = true;
                s1 = s.Substring(0,i);
                s2 = s.Substring(i+1);
                    
               }

            }

           double num;
            if(c =='+')
            {
                num = Convert.ToDouble(s1) + Convert.ToDouble(s2);
            }
           
            else if(c=='-')
            {
                 num = Convert.ToDouble(s1) - Convert.ToDouble(s2);
            }

            else if (c == '*')
            {
              num = Convert.ToDouble(s1) * Convert.ToDouble(s2);
            }

            else
            {
                num = Convert.ToDouble(s1) / Convert.ToDouble(s2);
            }
            hesab.Content = num.ToString();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {

            }
            else
            {
                for (int i = 0; i < s.Length; i++)
                {
                    if (s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/')
                    {
                        equals_Click(sender, e);

                    }
                }
                hesab.Content += cixma.Content.ToString();
            }
        }

        private void vurma_Click(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {

            }
            else
            {
                for (int i = 0; i < s.Length; i++)
                {
                    if (s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/')
                    {
                        equals_Click(sender, e);

                    }
                }
                hesab.Content += vurma.Content.ToString();
            }
        }

        private void divide_Click(object sender, RoutedEventArgs e)
        {
            string s = hesab.Content.ToString();
            if (s.Length == 1 && s[0] == '0')
            {

            }
            else
            {
                for (int i = 0; i < s.Length; i++)
                {
                    if (s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/')
                    {
                        equals_Click(sender, e);

                    }
                }
                hesab.Content += divide.Content.ToString();
            }
        }
    }
}
